let EnhancedTaskModel;

if (typeof module !== 'undefined' && module.exports) {
    EnhancedTaskModel = require('../models/EnhancedTask');
} else {
    EnhancedTaskModel = window.EnhancedTask;
}

class TaskRepository {
    constructor(storageManager) {
        this.storage = storageManager;
        this.tasks = new Map();
        this.storageKey = 'tasks';
        this.TaskClass = EnhancedTaskModel;
        
        this._loadTasksFromStorage();
    }
    
    create(taskData) {
        try {
            const task = new this.TaskClass(
                taskData.title,
                taskData.description,
                taskData.ownerId,
                taskData
            );
            
            this.tasks.set(task.id, task);
            this._saveTasksToStorage();
            
            return task;
        } catch (error) {
            console.error('Error creating task:', error);
            throw error;
        }
    }
    
    findById(id) {
        return this.tasks.get(id) || null;
    }
    
    findAll() {
        return Array.from(this.tasks.values());
    }
    
    findByOwner(ownerId) {
        return this.findAll().filter(task => task.ownerId === ownerId);
    }
    
    findByAssignee(assigneeId) {
        return this.findAll().filter(task => task.assigneeId === assigneeId);
    }
    
    findByCategory(category) {
        return this.findAll().filter(task => task.category === category);
    }
    
    findByStatus(status) {
        return this.findAll().filter(task => task.status === status);
    }
    
    findByPriority(priority) {
        return this.findAll().filter(task => task.priority === priority);
    }
    
    findOverdue() {
        return this.findAll().filter(task => task.isOverdue);
    }
    
    findDueSoon(days = 3) {
        return this.findAll().filter(task => {
            const daysUntilDue = task.daysUntilDue;
            return daysUntilDue !== null && daysUntilDue <= days && daysUntilDue >= 0;
        });
    }
    
    findByTag(tag) {
        return this.findAll().filter(task => task.tags.includes(tag));
    }
    
    update(id, updates) {
        const task = this.findById(id);
        if (!task) return null;
        
        try {
            if (updates.title !== undefined) task.updateTitle(updates.title);
            if (updates.description !== undefined) task.updateDescription(updates.description);
            if (updates.category !== undefined) task.updateCategory(updates.category);
            if (updates.priority !== undefined) task.updatePriority(updates.priority);
            if (updates.status !== undefined) task.updateStatus(updates.status);
            if (updates.dueDate !== undefined) task.setDueDate(updates.dueDate);
            if (updates.assigneeId !== undefined) task.assignTo(updates.assigneeId);
            if (updates.estimatedHours !== undefined) task.setEstimatedHours(updates.estimatedHours);
            if (updates.addTimeSpent !== undefined) task.addTimeSpent(updates.addTimeSpent);
            if (updates.addTag !== undefined) task.addTag(updates.addTag);
            if (updates.removeTag !== undefined) task.removeTag(updates.removeTag);
            if (updates.addNote !== undefined) task.addNote(updates.addNote);
            
            this._saveTasksToStorage();
            return task;
        } catch (error) {
            console.error('Error updating task:', error);
            throw error;
        }
    }
    
    delete(id) {
        if (this.tasks.has(id)) {
            this.tasks.delete(id);
            this._saveTasksToStorage();
            return true;
        }
        return false;
    }
    
    search(query) {
        const searchTerm = query.toLowerCase();
        return this.findAll().filter(task =>
            task.title.toLowerCase().includes(searchTerm) ||
            task.description.toLowerCase().includes(searchTerm) ||
            task.tags.some(tag => tag.toLowerCase().includes(searchTerm))
        );
    }
    
    filter(filters) {
        let results = this.findAll();
        if (filters.ownerId) results = results.filter(task => task.ownerId === filters.ownerId);
        if (filters.assigneeId) results = results.filter(task => task.assigneeId === filters.assigneeId);
        if (filters.category) results = results.filter(task => task.category === filters.category);
        if (filters.status) results = results.filter(task => task.status === filters.status);
        if (filters.priority) results = results.filter(task => task.priority === filters.priority);
        if (filters.overdue) results = results.filter(task => task.isOverdue);
        if (filters.dueSoon) {
            results = results.filter(task => {
                const days = task.daysUntilDue;
                return days !== null && days <= 3 && days >= 0;
            });
        }
        if (filters.tags && filters.tags.length > 0) {
            results = results.filter(task => filters.tags.some(tag => task.tags.includes(tag)));
        }
        return results;
    }
    
    sort(tasks, sortBy = 'createdAt', order = 'desc') {
        return tasks.sort((a, b) => {
            let valueA, valueB;
            switch (sortBy) {
                case 'title':
                    valueA = a.title.toLowerCase();
                    valueB = b.title.toLowerCase();
                    break;
                case 'priority':
                    const priorityOrder = { 'low': 1, 'medium': 2, 'high': 3, 'urgent': 4 };
                    valueA = priorityOrder[a.priority];
                    valueB = priorityOrder[b.priority];
                    break;
                case 'dueDate':
                    valueA = a.dueDate || new Date('9999-12-31');
                    valueB = b.dueDate || new Date('9999-12-31');
                    break;
                case 'createdAt':
                case 'updatedAt':
                    valueA = a[sortBy];
                    valueB = b[sortBy];
                    break;
                default:
                    valueA = a.createdAt;
                    valueB = b.createdAt;
            }
            if (order === 'asc') return valueA > valueB ? 1 : valueA < valueB ? -1 : 0;
            return valueA < valueB ? 1 : valueA > valueB ? -1 : 0;
        });
    }
    
    getStats(userId = null) {
        let tasks = userId ? this.findByOwner(userId) : this.findAll();
        const stats = {
            total: tasks.length,
            byStatus: {},
            byPriority: {},
            byCategory: {},
            overdue: tasks.filter(task => task.isOverdue).length,
            dueSoon: tasks.filter(task => {
                const days = task.daysUntilDue;
                return days !== null && days <= 3 && days >= 0;
            }).length,
            completed: tasks.filter(task => task.isCompleted).length
        };
        ['pending', 'in-progress', 'blocked', 'completed', 'cancelled'].forEach(s => {
            stats.byStatus[s] = tasks.filter(t => t.status === s).length;
        });
        ['low', 'medium', 'high', 'urgent'].forEach(p => {
            stats.byPriority[p] = tasks.filter(t => t.priority === p).length;
        });
        ['work', 'personal', 'study', 'health', 'finance', 'other'].forEach(c => {
            stats.byCategory[c] = tasks.filter(t => t.category === c).length;
        });
        return stats;
    }
    
    _loadTasksFromStorage() {
        try {
            const tasksData = this.storage.load(this.storageKey, []);
            tasksData.forEach(data => {
                try {
                    const task = this.TaskClass.fromJSON(data);
                    this.tasks.set(task.id, task);
                } catch (e) { console.error('Error loading task:', data, e); }
            });
        } catch (e) { console.error('Error loading tasks:', e); }
    }
    
    _saveTasksToStorage() {
        try {
            const tasksData = Array.from(this.tasks.values()).map(t => t.toJSON());
            this.storage.save(this.storageKey, tasksData);
        } catch (e) { console.error('Error saving tasks:', e); }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = TaskRepository;
} else {
    window.TaskRepository = TaskRepository;
}
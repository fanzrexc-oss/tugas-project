let UserModel;

if (typeof module !== 'undefined' && module.exports) {
    UserModel = require('../models/User');
} else {
    UserModel = window.User;
}

class UserRepository {
    constructor(storageManager) {
        this.storage = storageManager;
        this.users = new Map();
        this.storageKey = 'users';
        this.UserClass = UserModel;
        
        this._loadUsersFromStorage();
    }
    
    create(userData) {
        try {
            if (this.findByUsername(userData.username)) {
                throw new Error(`Username '${userData.username}' sudah digunakan`);
            }
            
            if (this.findByEmail(userData.email)) {
                throw new Error(`Email '${userData.email}' sudah digunakan`);
            }
            
            const user = new this.UserClass(userData.username, userData.email, userData.fullName);
            
            this.users.set(user.id, user);
            this._saveUsersToStorage();
            
            return user;
        } catch (error) {
            console.error('Error creating user:', error);
            throw error;
        }
    }
    
    findById(id) {
        return this.users.get(id) || null;
    }
    
    findByUsername(username) {
        const normalizedUsername = username.toLowerCase();
        for (const user of this.users.values()) {
            if (user.username === normalizedUsername) {
                return user;
            }
        }
        return null;
    }
    
    findByEmail(email) {
        const normalizedEmail = email.toLowerCase();
        for (const user of this.users.values()) {
            if (user.email === normalizedEmail) {
                return user;
            }
        }
        return null;
    }
    
    findAll() {
        return Array.from(this.users.values());
    }
    
    findActive() {
        return this.findAll().filter(user => user.isActive);
    }
    
    update(id, updates) {
        const user = this.findById(id);
        if (!user) return null;
        
        try {
            if (updates.fullName !== undefined || updates.email !== undefined) {
                user.updateProfile(updates.fullName, updates.email);
            }
            
            if (updates.preferences) {
                user.updatePreferences(updates.preferences);
            }
            
            if (updates.isActive !== undefined) {
                updates.isActive ? user.activate() : user.deactivate();
            }
            
            this._saveUsersToStorage();
            return user;
        } catch (error) {
            console.error('Error updating user:', error);
            throw error;
        }
    }
    
    delete(id) {
        const user = this.findById(id);
        if (!user) return false;
        
        user.deactivate();
        this._saveUsersToStorage();
        return true;
    }
    
    hardDelete(id) {
        if (this.users.has(id)) {
            this.users.delete(id);
            this._saveUsersToStorage();
            return true;
        }
        return false;
    }
    
    recordLogin(id) {
        const user = this.findById(id);
        if (user) {
            user.recordLogin();
            this._saveUsersToStorage();
        }
        return user;
    }
    
    search(query) {
        const searchTerm = query.toLowerCase();
        return this.findAll().filter(user => 
            user.username.includes(searchTerm) ||
            user.email.includes(searchTerm) ||
            user.fullName.toLowerCase().includes(searchTerm)
        );
    }
    
    getStats() {
        const allUsers = this.findAll();
        const activeUsers = this.findActive();
        
        return {
            total: allUsers.length,
            active: activeUsers.length,
            inactive: allUsers.length - activeUsers.length,
            recentLogins: allUsers.filter(user => {
                if (!user.lastLoginAt) return false;
                const dayAgo = new Date();
                dayAgo.setDate(dayAgo.getDate() - 1);
                return user.lastLoginAt > dayAgo;
            }).length
        };
    }
    
    _loadUsersFromStorage() {
        try {
            const usersData = this.storage.load(this.storageKey, []);
            
            usersData.forEach(userData => {
                try {
                    const user = this.UserClass.fromJSON(userData);
                    this.users.set(user.id, user);
                } catch (error) {
                    console.error('Error loading user:', userData, error);
                }
            });
        } catch (error) {
            console.error('Error loading users from storage:', error);
        }
    }
    
    _saveUsersToStorage() {
        try {
            const usersData = Array.from(this.users.values()).map(user => user.toJSON());
            this.storage.save(this.storageKey, usersData);
        } catch (error) {
            console.error('Error saving users to storage:', error);
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = UserRepository;
} else {
    window.UserRepository = UserRepository;
}